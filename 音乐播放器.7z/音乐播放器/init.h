#ifndef __INIT_H__
#define __INIT_H__

#include<reg52.h>

#define uchar unsigned char
#define uint unsigned int

void delay1();
void delay_ms(unsigned int ms);
void delay_us(unsigned int us);


#endif