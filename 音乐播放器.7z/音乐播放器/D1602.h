#ifndef __D1602_H__
#define __D1602_H__

void init();
void xzl(unsigned char com);
void xsj(unsigned char dat);

#endif